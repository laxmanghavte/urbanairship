<?php

namespace UrbanAirship;

class About {
	const LIBRARY_VERSION = '0.3.0';
}